//user id cookie name, if logged
exports.uid = "user_id"